package modelo;

import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.Serializable;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
/**
 * Clase Abstracta Proyectil
 * Esta clase abstracta es la base para el objeto Proyectil que ser� usado para eliminar las pelotas del juego.
 * @author Javier Andres Torres, Maria Camila Lenis, Juan Sebastian Palma
 * @version 1.0
 */
public abstract class Proyectil extends SpriteMovimiento implements Colisionable, Disparable{
	//Constantes
	/**
	 * Sonido del disparo
	 */
	public static final String DISPARO = "img/disparo.wav";
	/**
	 * Nivel de da�o que tiene frente a las pelotas
	 */
	private int danio;
	/**
	 * Velocidad con la que se desplazar� por la pantalla
	 */
	private int velocidad;
	
	//Contructor
	/**
	 * Crea un la base de un proyectil que por el momento es invisible
	 */
	public Proyectil() {
		super(0, 0, null);
		setVisible(false);
	}
	/**
	 * Getter del da�o<br>
	 * <b>post:</b>Devuelve el da�o del proyectil<br>
	 * @return El da�o que posee el proyectil
	 */
	public int getDanio() {
		return danio;
	}
	/**
	 * Getter de la velocidad<br>
	 * <b>post:</b>Devuelve la velocidad del proyectil<br>
	 * @return La velocidad que posee el proyectil
	 */
	public int getVelocidad() {
		return velocidad;
	}
	/**
	 * Setter del da�o<br>
	 * <b>post:</b>Asigna el da�o al poryectil<br>
	 * @param danio El nuevo da�o que tendr� el proyectil. danio!=null, danio debe ser mayor a 0.
	 */
	public void setDanio(int danio) {
		this.danio = danio;
	}
	/**
	 * Setter de la velocidad <br>
	 * <b>post:</b>Asigna la velocidad del proyectil<br>
	 * @param velocidad La nueva velocidad del proyectil. velocidad!=null, velocidad debe ser mayor a 0.
	 */
	public void setVelocidad(int velocidad) {
		this.velocidad = velocidad;
	}
	/**
	 * M�todo implementado de la interfaz Disparable<br>
	 * <b>pre:</b>El atributo velocidad ha sido inicializado<br>
	 * <b>post:</b>Se ha reproducido el sonido del disparo<br>
	 * <b>post:</b>Se ha cambiado en dX y el dY del proyectil<br>
	 * @param x Posici�n en x inicial del proyectil. x!=null, x debe ser mayor o igual a 0
	 * @param y Posici�n en y inicial del proyectil. y!=null, y debe ser mayor o igual a 0
	 * @param x2 Posici�n en x final del proyectil. x2!=null, x2 debe ser mayor o igual a 0
	 * @param y2 Posici�n en y final del proyectil. y2!=null, y2 debe ser mayor o igual a 0 
	 */
	@Override
	public void disparar(int x, int y, int x2, int y2) {
		if (!esVisible()) {
			try {
				Clip disparo = AudioSystem.getClip();
				disparo.open(AudioSystem.getAudioInputStream(new File(DISPARO)));
				disparo.start();
			} catch (Exception e) {
				e.printStackTrace();
			}
			setX(x);
			setY(y);
			setVisible(true);
			int difX = x2 - getX() + getAncho() / 2;
			int difY = y2 - getY() + getAlto() / 2;
			double hip = Math.sqrt(difX * difX + difY * difY);
			double prop = velocidad / hip;
			setDX((int) (prop * (x2 - getX())));
			setDY((int) (prop * (y2 - getY())));
		}
	}
	/**
	 * M�todo implementado de la interfaz Movible<br>
	 * Realiza el movimiento del proyectil y si alcanza los bordes de la pantalla se vuelve invisible<br>
	 * <b>pre:</b>Se ha intanciado un proyectil<br>
	 * <b>post:</b>Se ha cambiado su posici�n en x y en y <br>
	 * <b>post:</b>Si ha llegado a los bordes, se ha vuelto invisible<br>
	 */
	@Override
	public void mover() {
		super.mover();
		if (getX() < 0 || getX() + getAncho() > Juego.ANCHO || getY() < 0 || getY() + getAlto() > Juego.ALTO) {
			setVisible(false);
			setDX(0);
			setDY(0);
		}
	}
	/**
	 * M�todo implementado de la interfaz Colisionable<br>
	 * Vuelve el proyectil invisible si el objeto Colisionable con el que intersec� es una Pelota<br>
	 * <b>post:</b>Si c es una Pelota, el proyectil se vuelve invisible<br>
	 * @param c Objeto colisionable que intersec� con el proyectil. 
	 */
	@Override
	public void colisionaCon(Colisionable c) {
		if (c instanceof Pelota) {
			setVisible(false);
		}
	}
	/**
	 * M�todo implementado de la interfaz Colisionable<br>
	 * Verifica si existe una colisi�n entre un objeto Colisionable y otro<br>
	 * <b>post:</b>Devuelve si el proyectil ha intersecado o no con otro objeto Colisionable<br>
	 * @return True si ha colisionado, False si no ha colisionado
	 */
	@Override
	public boolean hayColision(Colisionable c) {
		return getHitbox().intersects(c.getHitbox());
	}
	/**
	 * M�todo implementado de la interfaz Colisionable<br>
	 * Retorna el HitBox del proyectil<br>
	 * <b>pre:</b>Los atributos x, y, ancho y alto han sido inicializados<br>
	 * <b>post:</b>Retorna el HitBox del proyectil<br>
	 * @return el HitBox Rectangular del proyectil. 
	 */
	@Override
	public Rectangle2D getHitbox() {
		return new Rectangle2D.Double(getX(), getY(), getAncho(), getAlto());
	}

	

}